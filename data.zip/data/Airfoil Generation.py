import os
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import interp1d

plt.rcParams.update({'font.size': 12})

import functions
from shape_plot import plot_shape
from utils import gen_grid

def compute_thickness_at_x(airfoil, x_target=0.25):
    """
    计算翼型在指定弦向位置 x_target 处的厚度（上下表面 y 坐标差）。
    假设翼型坐标按顺序排列：从后缘沿上表面到前缘，再沿下表面回到后缘，
    且弦长已归一化为 1。
    """
    x = airfoil[:, 0]
    y = airfoil[:, 1]
    le_idx = np.argmin(x)                     # 前缘索引（最小 x）

    # 分离上下表面
    upper = airfoil[:le_idx + 1]               # 包含前缘
    lower = airfoil[le_idx:]                   # 从前缘到后缘

    # 将上表面 x 反转为单调递增（从 LE 到 TE）
    upper_x = upper[:, 0][::-1]
    upper_y = upper[:, 1][::-1]
    # 下表面 x 已经是单调递增（从 LE 到 TE）
    lower_x = lower[:, 0]
    lower_y = lower[:, 1]

    # 插值函数（线性插值，超出范围返回 NaN）
    f_upper = interp1d(upper_x, upper_y, kind='linear',
                       bounds_error=False, fill_value=np.nan)
    f_lower = interp1d(lower_x, lower_y, kind='linear',
                       bounds_error=False, fill_value=np.nan)

    y_u = f_upper(x_target)
    y_l = f_lower(x_target)

    if np.isnan(y_u) or np.isnan(y_l):
        return np.nan          # 目标位置不在有效插值范围内
    return y_u - y_l

if __name__ == "__main__":
    # 参数设置
    target_num = 5000                         # 需要收集的翼型数量
    lower_thick = 0.175
    upper_thick = 0.185
    x_target = 0.25                          # 目标弦向位置（25% 弦长）
    batch_size = 100                         # 每次采样的数量
    max_attempts = 500000                    # 最大尝试次数（足够大）

    # 加载 BezierGAN 模型
    latent_dim = 3
    noise_dim = 10
    model_directory = './beziergan/trained_gan/{}_{}'.format(latent_dim, noise_dim)
    func = functions.AirfoilGAN(latent_dim, noise_dim, model_directory, full=True)

    # 创建保存目录
    save_dir = 'yixing_data'
    os.makedirs(save_dir, exist_ok=True)

    # 筛选满足厚度条件的翼型
    airfoils = []
    attempts = 0
    print(f"开始采样，目标收集 {target_num} 个厚度在 [{lower_thick:.3f}, {upper_thick:.3f}] 的翼型...")
    while len(airfoils) < target_num and attempts < max_attempts:
        samples = func.sample_airfoil(batch_size)
        for af in samples:
            thick = compute_thickness_at_x(af, x_target)
            if lower_thick <= thick <= upper_thick:
                airfoils.append(af)
                if len(airfoils) % 50 == 0:
                    print(f"已收集 {len(airfoils)} / {target_num} 个合格翼型")
                if len(airfoils) >= target_num:
                    break
        attempts += batch_size
        if attempts % 1000 == 0:
            print(f"已尝试 {attempts} 次，当前收集到 {len(airfoils)} 个合格翼型")

    if len(airfoils) < target_num:
        print(f"警告：在 {max_attempts} 次尝试后仅收集到 {len(airfoils)} 个合格翼型")
        # 用最后一个合格翼型填充至目标数量（如有需要）
        while len(airfoils) < target_num:
            airfoils.append(airfoils[-1])

    # 保存所有翼型的二维坐标为 NumPy 数组
    # 假设所有翼型点数相同，可转为三维数组 (num_airfoils, N_points, 2)
    # 否则保存为列表（推荐保存为列表以保留可变形状）
    print("保存翼型坐标...")
    np.save(os.path.join(save_dir, 'airfoils_coords.npy'), airfoils)  # 保存为列表的数组形式
    # 也可另存为单个三维数组（若点数固定）：
    # coords_array = np.array(airfoils)   # 可能需要检查形状一致
    # np.save(os.path.join(save_dir, 'airfoils_coords.npy'), coords_array)

    # 保存每个翼型的单独图像
    print("保存翼型图像...")
    for idx, af in enumerate(airfoils):
        fig, ax = plt.subplots(figsize=(4, 2))   # 设置合适的图形大小
        ax.plot(af[:, 0], af[:, 1], 'k-', linewidth=1.2)
        # 可选：填充内部（一般翼型填充可提高视觉效果）
        # ax.fill(af[:, 0], af[:, 1], 'lightgray', alpha=0.5)
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_xlim(0, 1)    # 弦长归一化为 0~1
        ax.set_ylim(-0.3, 0.3)  # 根据常见翼型厚度调整
        plt.tight_layout(pad=0)
        filename = f"airfoil_{idx+1:04d}.png"
        plt.savefig(os.path.join(save_dir, filename), dpi=150, bbox_inches='tight', pad_inches=0)
        plt.close(fig)

    print(f"完成！共保存 {len(airfoils)} 个翼型坐标和图像到 '{save_dir}' 文件夹。")