import os
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import interp1d

plt.rcParams.update({'font.size': 12})

import functions
from shape_plot import plot_shape
from utils import gen_grid

def compute_thickness_at_x(airfoil, x_target=0.25):

    x = airfoil[:, 0]
    y = airfoil[:, 1]
    le_idx = np.argmin(x)

    upper = airfoil[:le_idx + 1]
    lower = airfoil[le_idx:]


    upper_x = upper[:, 0][::-1]
    upper_y = upper[:, 1][::-1]

    lower_x = lower[:, 0]
    lower_y = lower[:, 1]


    f_upper = interp1d(upper_x, upper_y, kind='linear',
                       bounds_error=False, fill_value=np.nan)
    f_lower = interp1d(lower_x, lower_y, kind='linear',
                       bounds_error=False, fill_value=np.nan)

    y_u = f_upper(x_target)
    y_l = f_lower(x_target)

    if np.isnan(y_u) or np.isnan(y_l):
        return np.nan
    return y_u - y_l

if __name__ == "__main__":

    target_num = 5000
    lower_thick = 0.175
    upper_thick = 0.185
    x_target = 0.25
    batch_size = 100
    max_attempts = 500000

    latent_dim = 3
    noise_dim = 10
    model_directory = './beziergan/trained_gan/{}_{}'.format(latent_dim, noise_dim)
    func = functions.AirfoilGAN(latent_dim, noise_dim, model_directory, full=True)

    save_dir = 'yixing_data'
    os.makedirs(save_dir, exist_ok=True)


    airfoils = []
    attempts = 0
    print(f"开始采样，目标收集 {target_num} 个厚度在 [{lower_thick:.3f}, {upper_thick:.3f}] 的翼型...")
    while len(airfoils) < target_num and attempts < max_attempts:
        samples = func.sample_airfoil(batch_size)
        for af in samples:
            thick = compute_thickness_at_x(af, x_target)
            if lower_thick <= thick <= upper_thick:
                airfoils.append(af)
                if len(airfoils) % 50 == 0:
                    print(f"已收集 {len(airfoils)} / {target_num} 个合格翼型")
                if len(airfoils) >= target_num:
                    break
        attempts += batch_size
        if attempts % 1000 == 0:
            print(f"已尝试 {attempts} 次，当前收集到 {len(airfoils)} 个合格翼型")

    if len(airfoils) < target_num:
        print(f"警告：在 {max_attempts} 次尝试后仅收集到 {len(airfoils)} 个合格翼型")

        while len(airfoils) < target_num:
            airfoils.append(airfoils[-1])


    print("保存翼型坐标...")
    np.save(os.path.join(save_dir, 'airfoils_coords.npy'), airfoils)

    print("保存翼型图像...")
    for idx, af in enumerate(airfoils):
        fig, ax = plt.subplots(figsize=(4, 2))
        ax.plot(af[:, 0], af[:, 1], 'k-', linewidth=1.2)

        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_xlim(0, 1)
        ax.set_ylim(-0.3, 0.3)
        plt.tight_layout(pad=0)
        filename = f"airfoil_{idx+1:04d}.png"
        plt.savefig(os.path.join(save_dir, filename), dpi=150, bbox_inches='tight', pad_inches=0)
        plt.close(fig)

    print(f"完成！共保存 {len(airfoils)} 个翼型坐标和图像到 '{save_dir}' 文件夹。")