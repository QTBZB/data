import os
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, Matern, ConstantKernel as C, WhiteKernel
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score, KFold
from bayes_opt import BayesianOptimization
import joblib
import warnings
import json
import pickle
import time
from datetime import datetime

warnings.filterwarnings('ignore')


class GaussianProcessModel:
    def __init__(self, checkpoint_dir='checkpoints'):

        self.gp = None
        self.scaler_X = StandardScaler()
        self.scaler_y = StandardScaler()
        self.is_fitted = False
        self.best_params = None
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.optimizer_state_file = self.checkpoint_dir / 'optimizer_state.pkl'
        self.training_state_file = self.checkpoint_dir / 'training_state.json'

    def save_checkpoint(self, optimizer, X_scaled, y_scaled, current_iter, total_iter,
                        init_points_done, n_iter_done, best_params, best_score):

        try:

            optimizer_state = {
                'X_scaled': X_scaled,
                'y_scaled': y_scaled,
                'current_iter': current_iter,
                'total_iter': total_iter,
                'init_points_done': init_points_done,
                'n_iter_done': n_iter_done,
                'best_params': best_params,
                'best_score': best_score,
                'space': optimizer.space,
                'res': optimizer.res,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

            with open(self.optimizer_state_file, 'wb') as f:
                pickle.dump(optimizer_state, f)


            training_state = {
                'current_iter': current_iter,
                'total_iter': total_iter,
                'init_points_done': init_points_done,
                'n_iter_done': n_iter_done,
                'best_params': best_params,
                'best_score': best_score,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'progress': f"{current_iter}/{total_iter} ({(current_iter / total_iter * 100):.1f}%)"
            }

            with open(self.training_state_file, 'w') as f:
                json.dump(training_state, f, indent=4)

            print(f"检查点已保存: 进度 {training_state['progress']}")
            return True
        except Exception as e:
            print(f"保存检查点时出错: {e}")
            return False

    def load_checkpoint(self):

        if not self.optimizer_state_file.exists():
            print("未找到检查点，从头开始训练")
            return None

        try:
            print("找到检查点，正在恢复训练...")
            with open(self.optimizer_state_file, 'rb') as f:
                optimizer_state = pickle.load(f)


            print(f"恢复训练时间: {optimizer_state['timestamp']}")
            print(f"恢复进度: {optimizer_state['current_iter']}/{optimizer_state['total_iter']} "
                  f"({(optimizer_state['current_iter'] / optimizer_state['total_iter'] * 100):.1f}%)")
            print(f"最佳分数: {optimizer_state['best_score']:.6f}")

            return optimizer_state
        except Exception as e:
            print(f"加载检查点时出错: {e}")
            return None

    def train_with_bayesian_optimization(self, features, labels,
                                         n_iter=20, init_points=5, cv_folds=3, kappa=2.576,
                                         save_frequency=5):

        print("开始贝叶斯优化超参数...")
        print(f"使用采集函数 (kappa={kappa})")
        print(f"检查点目录: {self.checkpoint_dir}")

        # 标准化特征和标签
        X_scaled = self.scaler_X.fit_transform(features)
        y_scaled = self.scaler_y.fit_transform(labels.reshape(-1, 1)).flatten()


        optimizer_state = self.load_checkpoint()

        if optimizer_state is None:

            total_iter = init_points + n_iter
            current_iter = 0
            init_points_done = 0
            n_iter_done = 0
            best_score = -np.inf
            best_params = None


            print("从头开始贝叶斯优化...")
        else:

            X_scaled = optimizer_state['X_scaled']
            y_scaled = optimizer_state['y_scaled']
            current_iter = optimizer_state['current_iter']
            total_iter = optimizer_state['total_iter']
            init_points_done = optimizer_state['init_points_done']
            n_iter_done = optimizer_state['n_iter_done']
            best_score = optimizer_state['best_score']
            best_params = optimizer_state['best_params']


            print(f"从检查点恢复，已完成 {current_iter}/{total_iter} 次迭代")


        def gp_cv(rbf_length, matern_length, nu, noise_level):


            rbf_length = max(rbf_length, 0.01)
            matern_length = max(matern_length, 0.01)
            nu = max(nu, 0.1)
            noise_level = max(noise_level, 1e-6)


            kernel = C(1.0, (1e-3, 1e3)) * (
                    RBF(length_scale=rbf_length) *
                    Matern(length_scale=matern_length, nu=nu)
            ) + WhiteKernel(noise_level=noise_level)


            gp = GaussianProcessRegressor(
                kernel=kernel,
                n_restarts_optimizer=2,
                alpha=1e-10,
                normalize_y=True
            )

            try:

                kfold = KFold(n_splits=cv_folds, shuffle=True, random_state=42)
                scores = cross_val_score(gp, X_scaled, y_scaled,
                                         cv=kfold, scoring='neg_mean_squared_error',
                                         n_jobs=-1)


                return np.mean(scores)
            except:

                return -1e10


        pbounds = {
            'rbf_length': (0.1, 5.0),
            'matern_length': (0.1, 5.0),
            'nu': (0.5, 2.5),
            'noise_level': (1e-5, 1e-1)
        }


        if optimizer_state is None:
            optimizer = BayesianOptimization(
                f=gp_cv,
                pbounds=pbounds,
                random_state=42,
                verbose=1
            )
        else:

            optimizer = BayesianOptimization(
                f=gp_cv,
                pbounds=pbounds,
                random_state=42,
                verbose=1
            )

            if hasattr(optimizer_state, 'res'):
                for res in optimizer_state['res']:
                    optimizer.register(params=res['params'], target=res['target'])


        remaining_init_points = max(0, init_points - init_points_done)
        remaining_n_iter = max(0, n_iter - n_iter_done)

        print(f"\n优化进度:")
        print(f"  总迭代: {total_iter}")
        print(f"  已完成: {current_iter}")
        print(f"  剩余随机点: {remaining_init_points}")
        print(f"  剩余贝叶斯迭代: {remaining_n_iter}")

        try:

            if remaining_init_points > 0 or remaining_n_iter > 0:

                for i in range(remaining_init_points + remaining_n_iter):

                    optimizer.maximize(
                        init_points=1 if i < remaining_init_points else 0,
                        n_iter=1,
                        acq='ucb',
                        kappa=kappa
                    )

                    current_iter += 1
                    if i < remaining_init_points:
                        init_points_done += 1
                    else:
                        n_iter_done += 1


                    if optimizer.max['target'] > best_score:
                        best_score = optimizer.max['target']
                        best_params = optimizer.max['params']

                    if current_iter % save_frequency == 0 or current_iter == total_iter:
                        self.save_checkpoint(
                            optimizer, X_scaled, y_scaled, current_iter, total_iter,
                            init_points_done, n_iter_done, best_params, best_score
                        )

                    print(f"\r进度: {current_iter}/{total_iter} ({current_iter / total_iter * 100:.1f}%)", end="")

                print(f"\n贝叶斯优化完成!")

            self.best_params = best_params

            print(f"最佳参数: {self.best_params}")
            print(f"最佳得分（负MSE）: {best_score:.6f}")

        except Exception as e:
            print(f"\n优化过程中出错: {e}")
            print("已保存检查点，可以在修复错误后继续运行")
            raise e


        print("\n使用最佳参数训练最终模型...")
        kernel = C(1.0, (1e-3, 1e3)) * (
                RBF(length_scale=self.best_params['rbf_length']) *
                Matern(length_scale=self.best_params['matern_length'],
                       nu=self.best_params['nu'])
        ) + WhiteKernel(noise_level=self.best_params['noise_level'])

        self.gp = GaussianProcessRegressor(
            kernel=kernel,
            n_restarts_optimizer=10,
            alpha=1e-10,
            normalize_y=True
        )

        self.gp.fit(X_scaled, y_scaled)

        print(f'优化的核函数: {self.gp.kernel_}')


        if self.optimizer_state_file.exists():
            self.optimizer_state_file.unlink()
        if self.training_state_file.exists():
            self.training_state_file.unlink()
        print("训练完成，检查点已清除")

        self.is_fitted = True

        return self.best_params, best_score

    def get_training_progress(self):

        if self.training_state_file.exists():
            try:
                with open(self.training_state_file, 'r') as f:
                    state = json.load(f)
                return state
            except:
                return None
        return None

    def resume_training(self, features, labels, cv_folds=3, kappa=2.576, save_frequency=5):

        return self.train_with_bayesian_optimization(
            features, labels,
            n_iter=0,
            init_points=0,
            cv_folds=cv_folds,
            kappa=kappa,
            save_frequency=save_frequency
        )


    def predict(self, features):

        if not self.is_fitted:
            raise ValueError("模型未训练，请先调用train_with_bayesian_optimization方法")


        X_scaled = self.scaler_X.transform(features)


        y_pred_scaled, y_std_scaled = self.gp.predict(X_scaled, return_std=True)

        y_pred = self.scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1))

        y_std = y_std_scaled * np.std(self.scaler_y.transform(np.zeros((1, 1))))

        return y_pred, y_std

    def visualize_kernel_comparison(self):

        if not self.is_fitted:
            print("模型未训练，无法可视化核函数")
            return

        kernel_params = str(self.gp.kernel_)
        import re

        rbf_match = re.search(r'RBF\(length_scale=([0-9.e+-]+)', kernel_params)
        matern_match = re.search(r'Matern\(length_scale=([0-9.e+-]+)', kernel_params)

        if rbf_match and matern_match:
            rbf_length = float(rbf_match.group(1))
            matern_length = float(matern_match.group(1))


            nu_match = re.search(r'nu=([0-9.e+-]+)', kernel_params)
            nu_value = float(nu_match.group(1)) if nu_match else 1.5

            x = np.linspace(-3, 3, 200)


            rbf_values = np.exp(-x ** 2 / (2 * rbf_length ** 2))


            matern_values = (1 + np.sqrt(3) * np.abs(x) / matern_length) * np.exp(
                -np.sqrt(3) * np.abs(x) / matern_length)


            product_values = rbf_values * matern_values


            exponential_values = np.exp(-np.abs(x) / matern_length)


            matern52_values = (1 + np.sqrt(5) * np.abs(x) / matern_length +
                               5 * x ** 2 / (3 * matern_length ** 2)) * np.exp(-np.sqrt(5) * np.abs(x) / matern_length)

            plt.figure(figsize=(15, 10))


            plt.subplot(2, 3, 1)
            plt.plot(x, rbf_values, 'b-', linewidth=3, label=f'RBF核 (l={rbf_length:.3f})')
            plt.xlabel('距离 (x)')
            plt.ylabel('核函数值')
            plt.title('RBF核函数（高斯核）')
            plt.legend()
            plt.grid(True, alpha=0.3)

            plt.subplot(2, 3, 2)
            plt.plot(x, exponential_values, 'orange', linewidth=2, label=f'指数核 (nu=0.5)')
            plt.xlabel('距离 (x)')
            plt.ylabel('核函数值')
            plt.title('指数核 (Matern nu=0.5)')
            plt.legend()
            plt.grid(True, alpha=0.3)

            plt.subplot(2, 3, 3)
            plt.plot(x, matern_values, 'g-', linewidth=3, label=f'Matern32核 (l={matern_length:.3f})')
            plt.xlabel('距离 (x)')
            plt.ylabel('核函数值')
            plt.title(f'Matern32核函数 (nu=1.5)')
            plt.legend()
            plt.grid(True, alpha=0.3)

            plt.subplot(2, 3, 4)
            plt.plot(x, matern52_values, 'purple', linewidth=2, label=f'Matern52核')
            plt.xlabel('距离 (x)')
            plt.ylabel('核函数值')
            plt.title(f'Matern52核函数 (nu=2.5)')
            plt.legend()
            plt.grid(True, alpha=0.3)

            plt.subplot(2, 3, 5)
            plt.plot(x, product_values, 'r-', linewidth=3, label='RBF×Matern32乘积核')
            plt.xlabel('距离 (x)')
            plt.ylabel('核函数值')
            plt.title('乘积核函数')
            plt.legend()
            plt.grid(True, alpha=0.3)


            plt.subplot(2, 3, 6)
            plt.plot(x, rbf_values, 'b--', linewidth=1.5, alpha=0.7, label='RBF核')
            plt.plot(x, exponential_values, 'orange--', linewidth=1.5, alpha=0.7, label='指数核')
            plt.plot(x, matern_values, 'g--', linewidth=1.5, alpha=0.7, label='Matern32核')
            plt.plot(x, matern52_values, 'purple--', linewidth=1.5, alpha=0.7, label='Matern52核')
            plt.plot(x, product_values, 'r-', linewidth=2.5, label='乘积核')
            plt.xlabel('距离 (x)')
            plt.ylabel('核函数值')
            plt.title('所有核函数对比')
            plt.legend()
            plt.grid(True, alpha=0.3)

            plt.suptitle('核函数可视化对比', fontsize=16, fontweight='bold')
            plt.tight_layout()
            plt.show()


            print("\n核函数特性对比:")
            print("1. RBF核（高斯核）: 无限可微，非常平滑")
            print("2. 指数核 (Matern nu=0.5): 一次不可微，不连续")
            print("3. Matern32核 (nu=1.5): 一次可微，中等平滑")
            print("4. Matern52核 (nu=2.5): 二次可微，非常平滑")
            print("5. 乘积核 (RBF×Matern32): 结合两者特性")
        else:
            print("无法提取核函数参数")

    def save_model(self, model_path='model/gaussian_process_model_optimized.pkl'):

        if not self.is_fitted:
            raise ValueError("模型未训练，无法保存")

        Path(model_path).parent.mkdir(parents=True, exist_ok=True)

        joblib.dump({
            'gp': self.gp,
            'scaler_X': self.scaler_X,
            'scaler_y': self.scaler_y,
            'best_params': self.best_params
        }, str(model_path))

        print(f'模型保存到: {model_path}')

    def load_model(self, model_path='model/gaussian_process_model_optimized.pkl'):

        if Path(model_path).exists():
            model_data = joblib.load(model_path)
            self.gp = model_data['gp']
            self.scaler_X = model_data['scaler_X']
            self.scaler_y = model_data['scaler_y']
            self.best_params = model_data.get('best_params', None)
            self.is_fitted = True

            print(f"模型从 {model_path} 加载")
            print(f"使用的核函数: {self.gp.kernel_}")

            if self.best_params:
                print(f"贝叶斯优化得到的最佳参数:")
                for param, value in self.best_params.items():
                    print(f"  {param}: {value:.4f}")
        else:
            raise ValueError(f"模型文件 {model_path} 不存在")


def load_data(csv_file, npy_file):
    df = pd.read_csv(csv_file)
    list1 = df.iloc[:, 8].values
    data4 = np.load(npy_file)
    list2 = data4.tolist()
    data = [[list1[i], list2[i]] for i in range(len(list1))]
    features = np.array([[val for sublist in item[1] for val in sublist] for item in data], dtype=np.float32)
    labels = np.array(list1, dtype=np.float32).reshape(-1, 1)
    print(f'特征维度: {features.shape}')
    print(f'标签维度: {labels.shape}')
    return features, labels


if __name__ == '__main__':

    features, labels = load_data('airfoil SPL.csv', 'data/data1.npy')


    train_size = int(0.8 * len(features))
    X_train, X_test = features[:train_size], features[train_size:]
    y_train, y_test = labels[:train_size], labels[train_size:]

    print(f'\n训练集大小: {len(X_train)}')
    print(f'测试集大小: {len(X_test)}')


    print("\n" + "=" * 60)
    print("高斯过程回归模型训练 (支持断点续传)")
    print("采集函数: UCB (上界置信)")
    print("检查点目录: checkpoints/")
    print("=" * 60)

    model = GaussianProcessModel(checkpoint_dir='checkpoints')


    progress = model.get_training_progress()
    if progress:
        print(f"\n发现未完成的训练:")
        print(f"  进度: {progress['progress']}")
        print(f"  时间: {progress['timestamp']}")
        print(f"  最佳分数: {progress['best_score']:.6f}")

        choice = input("是否继续训练？(y/n): ")
        if choice.lower() == 'y':

            best_params, best_score = model.resume_training(
                X_train, y_train,
                cv_folds=3,
                kappa=2.576,
                save_frequency=5
            )
        else:

            print("重新开始训练...")
            checkpoint_dir = Path('checkpoints')
            for file in checkpoint_dir.glob('*'):
                file.unlink()
            best_params, best_score = model.train_with_bayesian_optimization(
                X_train, y_train,
                n_iter=20,
                init_points=5,
                cv_folds=3,
                kappa=2.576,
                save_frequency=5
            )
    else:

        best_params, best_score = model.train_with_bayesian_optimization(
            X_train, y_train,
            n_iter=20,
            init_points=5,
            cv_folds=3,
            kappa=2.576,
            save_frequency=5
        )


    model.visualize_kernel_comparison()

    print("\n" + "=" * 60)
    print("测试集预测")
    print("=" * 60)

    predictions, stds = model.predict(X_test)
    print(f"预测完成，得到 {len(predictions)} 个预测值")


    model.save_model()


    output_dir = Path('results')
    output_dir.mkdir(exist_ok=True)

    results_df = pd.DataFrame({
        'Predicted_Value': predictions.flatten(),
        'Std_Dev': stds,
        'Lower_Bound': (predictions - 1.96 * stds.reshape(-1, 1)).flatten(),
        'Upper_Bound': (predictions + 1.96 * stds.reshape(-1, 1)).flatten()
    })

    results_path = output_dir / 'predictions_optimized_ucb.csv'
    results_df.to_csv(results_path, index=False)
    print(f'\n预测结果已保存到: {results_path}')


    if best_params:
        params_df = pd.DataFrame([best_params])
        params_path = output_dir / 'optimized_parameters_ucb.csv'
        params_df.to_csv(params_path, index=False)
        print(f'优化参数已保存到: {params_path}')