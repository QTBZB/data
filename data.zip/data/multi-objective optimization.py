import os
import joblib
from pathlib import Path
import numpy as np
import tensorflow as tf
from platypus import Problem, NSGAII, Real, Solution
from simulation import evaluate
from tqdm import tqdm
import matplotlib.pyplot as plt
from BO_GPR_train import BayesianGaussianProcessModel

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

bo_gpr_model = joblib.load('model/gaussian_process_model_optimized.pkl')
scaler_X = joblib.load('model/scaler_X.pkl')
scaler_y = joblib.load('model/scaler_y.pkl')


gan_model_directory = './beziergan/trained_gan/{}_{}'.format(3, 10)

best_ld_solution = None
best_noise_solution = None
best_ld_ratio = -np.inf
best_noise_value = np.inf


def initialize_airfoil_gan(gan_model_directory):
    from functions import AirfoilGAN
    return AirfoilGAN(3, 10, model_directory=gan_model_directory)



airfoil_gan_instance = initialize_airfoil_gan(gan_model_directory)


def generate_airfoil_data_with_params(params, airfoil_gan):

    airfoil_data = airfoil_gan.synthesize(np.array(params))


    points = airfoil_data.reshape(101, 2)


    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    chord_length = x_max - x_min

    normalized_x = (points[:, 0] - x_min) / chord_length
    normalized_y = points[:, 1] / chord_length

    normalized_airfoil = np.column_stack((normalized_x, normalized_y))

    f1 = evaluate(normalized_airfoil, 1.8e6, 0.01, 0.0, 200)

    return f1, normalized_airfoil.reshape(1, -1)


def predict_noise(airfoil_data):


    if airfoil_data.ndim == 1:
        airfoil_data = airfoil_data.reshape(1, -1)

    noise_pred = bo_gpr_model.predict(airfoil_data)

    if isinstance(noise_pred, np.ndarray):

        noise_value = noise_pred.item() if noise_pred.size == 1 else noise_pred[0, 0]
    else:
        noise_value = noise_pred


    if noise_value < 10:
        m = 100
        b = 44
        scaled_noise = m * noise_value + b

        print(f"Adjusted noise: {scaled_noise:.2f} dB (from raw value {noise_value:.4f})")
        return scaled_noise

    return noise_value


def objectives(variables):
    global best_ld_solution, best_noise_solution, best_ld_ratio, best_noise_value

    params = np.array(variables)


    f1, airfoils = generate_airfoil_data_with_params(params, airfoil_gan_instance)

    # 处理无效翼型（自相交）
    if np.isnan(f1):
        print("Unsuccessful: Self-intersecting! Setting high noise and low performance.")
        return [0, 100]


    f2 = predict_noise(airfoils)
    print(f"Predicted noise: {f2:.6f}")


    if f1 > best_ld_ratio:
        best_ld_ratio = f1
        best_ld_solution = {
            'variables': variables,
            'ld_ratio': f1,
            'noise': f2,
            'airfoil_data': airfoils
        }


    if f2 < best_noise_value:
        best_noise_value = f2
        best_noise_solution = {
            'variables': variables,
            'ld_ratio': f1,
            'noise': f2,
            'airfoil_data': airfoils
        }


    return [-f1, f2]


def save_airfoil_image(airfoil_data, filename, ld_ratio, noise):
    points = airfoil_data.reshape(101, 2)


    plt.figure(figsize=(10, 6))
    plt.plot(points[:, 0], points[:, 1], 'b-', linewidth=2)


    plt.xlim(0, 1)
    plt.ylim(np.min(points[:, 1]) - 0.05, np.max(points[:, 1]) + 0.05)
    plt.axis('equal')
    plt.grid(True)

    plt.title(f"Optimized Airfoil\nL/D: {ld_ratio:.4f}, Noise: {noise:.6f}")
    plt.xlabel('X Coordinate')
    plt.ylabel('Y Coordinate')


    plt.savefig(filename)
    plt.close()


def nsgaii_optimization(iterations=10, log_file='nsgaii_log0.csv', convergence_plot_file='convergence_plot0.png'):
    global best_ld_solution, best_noise_solution, best_ld_ratio, best_noise_value

    best_ld_solution = None
    best_noise_solution = None
    best_ld_ratio = -np.inf
    best_noise_value = np.inf


    problem = Problem(3, 2)
    problem.types[:] = [Real(-1, 1), Real(-1, 1), Real(-1, 1)]
    problem.function = objectives


    algorithm = NSGAII(problem)
    algorithm.run(iterations)

    with open(log_file, 'w') as file:
        file.write('iteration,best_f1,best_f2\n')

    best_f1_values = []
    best_f2_values = []

    for i in tqdm(range(iterations), desc="NSGA-II Optimization"):
        algorithm.step()

        non_dominated_solutions = sorted(algorithm.result, key=lambda x: (-x.objectives[0], x.objectives[1]))
        if non_dominated_solutions:
            best_solution = non_dominated_solutions[0]
            with open(log_file, 'a') as file:
                file.write(f'{i + 1},{-best_solution.objectives[0]},{best_solution.objectives[1]}\n')


            best_f1_values.append(-best_solution.objectives[0])
            best_f2_values.append(best_solution.objectives[1])


    fig, ax1 = plt.subplots(figsize=(10, 6))

    color = 'tab:blue'
    ax1.set_xlabel('Iteration')
    ax1.set_ylabel('Max Lift-to-Drag Ratio (f1)', color=color)
    ax1.plot(range(1, iterations + 1), best_f1_values, color=color, linewidth=2)
    ax1.tick_params(axis='y', labelcolor=color)
    ax1.grid(True, linestyle='--', alpha=0.7)

    ax2 = ax1.twinx()
    color = 'tab:red'
    ax2.set_ylabel('Min Aerodynamic Noise (f2)', color=color)
    ax2.plot(range(1, iterations + 1), best_f2_values, color=color, linewidth=2)
    ax2.tick_params(axis='y', labelcolor=color)
    ax2.grid(True, linestyle='--', alpha=0.7)

    plt.title('Optimization Convergence')
    fig.tight_layout()
    plt.savefig(convergence_plot_file, dpi=300)
    plt.show()


    os.makedirs('optimized_airfoils', exist_ok=True)


    print("\nFinal Pareto Front Solutions:")
    for idx, solution in enumerate(non_dominated_solutions):

        ld_ratio = -solution.objectives[0]
        noise = solution.objectives[1]

        _, airfoil_data = generate_airfoil_data_with_params(solution.variables, airfoil_gan_instance)


        data_filename = f'optimized_airfoils/airfoil_{idx + 1}.txt'
        np.savetxt(data_filename, airfoil_data.reshape(101, 2), fmt='%.6f')


        image_filename = f'optimized_airfoils/airfoil_{idx + 1}.png'
        save_airfoil_image(airfoil_data, image_filename, ld_ratio, noise)


        print(f"\nSolution {idx + 1}:")
        print(f"  Variables: {solution.variables}")
        print(f"  Lift-to-drag ratio: {ld_ratio:.4f}")
        print(f"  Predicted noise: {noise:.6f}")
        print(f"  Airfoil data saved to: {data_filename}")
        print(f"  Airfoil image saved to: {image_filename}")


    ideal_point = [min(-s.objectives[0] for s in non_dominated_solutions),
                   min(s.objectives[1] for s in non_dominated_solutions)]

    best_compromise = None
    min_distance = float('inf')

    for solution in non_dominated_solutions:

        distance = np.sqrt(
            (-solution.objectives[0] - ideal_point[0]) ** 2 +
            (solution.objectives[1] - ideal_point[1]) ** 2
        )

        if distance < min_distance:
            min_distance = distance
            best_compromise = solution

    if best_compromise:

        ld_ratio = -best_compromise.objectives[0]
        noise = best_compromise.objectives[1]

        _, airfoil_data = generate_airfoil_data_with_params(best_compromise.variables, airfoil_gan_instance)


        data_filename = 'optimized_airfoils/best_compromise_airfoil.txt'
        np.savetxt(data_filename, airfoil_data.reshape(101, 2), fmt='%.6f')


        image_filename = 'optimized_airfoils/best_compromise_airfoil.png'
        save_airfoil_image(airfoil_data, image_filename, ld_ratio, noise)

        print("\nBest Compromise Solution (Closest to Ideal Point):")
        print(f"  Lift-to-drag ratio: {ld_ratio:.4f}")
        print(f"  Predicted noise: {noise:.6f}")
        print(f"  Airfoil data saved to: {data_filename}")
        print(f"  Airfoil image saved to: {image_filename}")


    if best_ld_solution:
        airfoil_data = best_ld_solution['airfoil_data']
        data_filename = 'optimized_airfoils/best_ld_airfoil.txt'
        np.savetxt(data_filename, airfoil_data.reshape(101, 2), fmt='%.6f')

        image_filename = 'optimized_airfoils/best_ld_airfoil.png'
        save_airfoil_image(airfoil_data, image_filename, best_ld_solution['ld_ratio'], best_ld_solution['noise'])

        print("\nBest Lift-to-Drag Ratio Airfoil:")
        print(f"  Variables: {best_ld_solution['variables']}")
        print(f"  Lift-to-drag ratio: {best_ld_solution['ld_ratio']:.4f}")
        print(f"  Predicted noise: {best_ld_solution['noise']:.6f}")
        print(f"  Airfoil data saved to: {data_filename}")
        print(f"  Airfoil image saved to: {image_filename}")


    if best_noise_solution:
        airfoil_data = best_noise_solution['airfoil_data']
        data_filename = 'optimized_airfoils/best_noise_airfoil.txt'
        np.savetxt(data_filename, airfoil_data.reshape(101, 2), fmt='%.6f')

        image_filename = 'optimized_airfoils/best_noise_airfoil.png'
        save_airfoil_image(airfoil_data, image_filename, best_noise_solution['ld_ratio'], best_noise_solution['noise'])

        print("\nBest Noise Airfoil:")
        print(f"  Variables: {best_noise_solution['variables']}")
        print(f"  Lift-to-drag ratio: {best_noise_solution['ld_ratio']:.4f}")
        print(f"  Predicted noise: {best_noise_solution['noise']:.6f}")
        print(f"  Airfoil data saved to: {data_filename}")
        print(f"  Airfoil image saved to: {image_filename}")


if __name__ == '__main__':

    nsgaii_optimization(iterations=10, log_file='nsgaii_log0.csv', convergence_plot_file='convergence_plot0.png')